import React, { useEffect, useState, useMemo } from "react";
import axios from "axios";
import pLimit from "p-limit";
import {
  Card,
  Tabs,
  Row,
  Col,
  Statistic,
  Progress,
  Tag,
  Spin,
  Alert,
} from "antd";
import { ArrowUpOutlined, ArrowDownOutlined } from "@ant-design/icons";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";
import zoomPlugin from "chartjs-plugin-zoom";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
  zoomPlugin
);

const SERIES = [
  { id: "DGS10", label: "미국채 10년 (DGS10)" },
  { id: "CPIAUCSL", label: "CPI (CPIAUCSL)" },
  { id: "T10Y2Y", label: "10Y-2Y (T10Y2Y)" },
  { id: "M2SL", label: "M2 (M2SL)" },
  { id: "BAMLH0A0HYM2", label: "하이일드 스프레드 (BAMLH0A0HYM2)" },
  { id: "VIXCLS", label: "VIX (VIXCLS)" },
  { id: "PCOPPUSDM", label: "구리 가격 (proxy PCOPPUSDM)" },
  { id: "SP500", label: "S&P 500 (SP500)" },
  { id: "CBBTCUSD", label: "Bitcoin (CBBTCUSD)" },
];

function normalizeData(arr) {
  if (!arr || arr.length === 0) return [];
  const vals = arr.filter((v) => typeof v === "number" && !isNaN(v));
  const min = Math.min(...vals),
    max = Math.max(...vals);
  return max === min
    ? arr.map(() => 50)
    : arr.map((v) => ((v - min) / (max - min)) * 100);
}

function calcChangePct(history) {
  if (!history || history.length < 2) return 0;
  const [prev, last] = [history[history.length - 2], history[history.length - 1]];
  return prev ? ((last - prev) / Math.abs(prev)) * 100 : 0;
}

function MiniStat({ label, value, change, statusText, statusType }) {
  return (
    <Card size="small" style={{ marginBottom: 8 }}>
      <Statistic
        title={label}
        value={value}
        precision={2}
        valueStyle={{
          color:
            statusType === "good"
              ? "#3f8600"
              : statusType === "bad"
              ? "#cf1322"
              : "#faad14",
        }}
        prefix={change > 0 ? <ArrowUpOutlined /> : change < 0 ? <ArrowDownOutlined /> : null}
        suffix={
          <Tag color={statusType === "good" ? "success" : statusType === "bad" ? "error" : "default"}>
            {statusText}
          </Tag>
        }
      />
      <Progress percent={Math.min(100, Math.abs(change))} showInfo={false} size="small" />
    </Card>
  );
}

export default function InvestIndicator() {
  const [data, setData] = useState({});
  const [dates, setDates] = useState({});
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState(null);
  const [activeTab, setActiveTab] = useState("all");
  const releaseId = 52; // 필요하다면 변경

  // 단일 시리즈를 불러와 {values, dates} 형태로 반환
  async function fetchSeries(seriesId) {
    const res = await axios.get("/invest/fred-series/", {
      params: { release_id: releaseId, series_id: seriesId },
      timeout: 15000,
    });
    const values = Array.isArray(res.data.values) ? res.data.values : [];
    const dates = Array.isArray(res.data.dates) ? res.data.dates : [];
    return { values, dates };
  }

  // 병렬로 모든 SERIES 데이터를 가져옴
  async function fetchAll() {
    setLoading(true);
    setErrorMsg(null);
    const limit = pLimit(6);
    const results = {};
    const dateMap = {};
    try {
      await Promise.all(
        SERIES.map((s) =>
          limit(async () => {
            const { values, dates } = await fetchSeries(s.id);
            results[s.id] = values;
            dateMap[s.id] = dates;
          })
        )
      );
      setData(results);
      setDates(dateMap);
    } catch (e) {
      console.error(e);
      setErrorMsg("데이터 로드 중 오류가 발생했습니다.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const seriesMeta = useMemo(() => {
    return SERIES.reduce((acc, s, i) => {
      acc[s.id] = { label: s.label, color: `hsl(${(i * 60) % 360},70%,40%)` };
      return acc;
    }, {});
  }, []);

  if (loading) return <Spin size="large" style={{ margin: 24 }} />;
  if (errorMsg) return <Alert type="error" message={errorMsg} style={{ margin: 24 }} />;

  const tabKeys = ["all", ...SERIES.map((s) => s.id)];
  const items = tabKeys.map((tabKey) => {
    const label = tabKey === "all" ? "All (Normalized 비교)" : seriesMeta[tabKey].label;
    return {
      key: tabKey,
      label,
      children: (
        <Row gutter={16}>
          <Col xs={24} lg={8}>
            <Card title="Latest Values">
              {tabKey === "all" ? (
                SERIES.map((s) => {
                  const hist = data[s.id] || [];
                  const latest = hist[hist.length - 1] ?? "N/A";
                  return (
                    <div key={s.id} style={{ marginBottom: 8 }}>
                      <strong>{s.label}:</strong> {latest}
                    </div>
                  );
                })
              ) : (
                (() => {
                  const hist = data[tabKey] || [];
                  if (!hist.length) return <div>No data</div>;
                  const latest = hist[hist.length - 1];
                  const change = calcChangePct(hist);
                  return (
                    <>
                      <div style={{ marginBottom: 8 }}>
                        <strong>Latest:</strong> {latest}
                      </div>
                      <div style={{ marginBottom: 8 }}>
                        <strong>Change (최근):</strong> {change.toFixed(2)}%
                      </div>
                      <Progress
                        percent={Math.min(100, Math.abs(change))}
                        status={change < 0 ? "exception" : "normal"}
                      />
                    </>
                  );
                })()
              )}
            </Card>
          </Col>
          <Col xs={24} lg={16}>
            <Card title={label + (tabKey === "all" ? "" : " 추세")}>
              <div style={{ height: 420 }}>
                <Line
                  data={{
                    labels:
                      tabKey === "all"
                        ? (dates[SERIES[0].id] || []).slice(-365)
                        : dates[tabKey] || dates[SERIES[0].id] || [],
                    datasets:
                      tabKey === "all"
                        ? SERIES.filter((s) => data[s.id]?.length).map((s) => ({
                            label: seriesMeta[s.id].label, data:
                            normalizeData(data[s.id].slice(-365)),
                            borderColor: seriesMeta[s.id].color,
                            backgroundColor: "transparent",
                            tension: 0.2,
                            pointRadius: 0,
                          }))
                        : [
                            {
                              label: seriesMeta[tabKey].label, data:
                              normalizeData(data[tabKey] || []),
                              borderColor: seriesMeta[tabKey].color,
                              backgroundColor: "transparent",
                              tension: 0.2,
                              pointRadius: 0,
                            },
                          ],
                  }}
                  options={{
                    maintainAspectRatio: false,
                    plugins: {
                      legend: { position: "top" },
                      zoom: {
                        pan: { enabled: true, mode: "x" },
                        zoom: { wheel: { enabled: true }, pinch: { enabled: true }, mode: "x" },
                      },
                    },
                    scales: {
                      y: { title: { display: true, text: tabKey === "all" ? "Normalized (0-100)" : "" } },
                      x: { ticks: { maxTicksLimit: 12 } },
                    },
                  }}
                />
              </div>
            </Card>
          </Col>
        </Row>
      ),
    };
  });

  return (
    <div style={{ padding: 16 }}>
      <Card title="Market Dashboard (FRED 기반)" style={{ marginBottom: 16 }}>
        <Row gutter={16}>
          {SERIES.map((s) => {
            const hist = data[s.id] || [];
            const latest = hist[hist.length - 1] ?? "N/A";
            const change = calcChangePct(hist);
            const statusType = change < -2 ? "bad" : change > 2 ? "good" : "neutral";
            return (
              <Col xs={24} sm={12} md={8} lg={6} key={s.id}>
                <MiniStat
                  label={s.label}
                  value={latest}
                  change={change}
                  statusText={statusType}
                  statusType={statusType}
                />
              </Col>
            );
          })}
        </Row>
      </Card>
      <Tabs activeKey={activeTab} onChange={setActiveTab} items={items} />
    </div>
  );
}